# heuristic.py
def manhattan_distance(pos1, pos2):
    x1, y1 = pos1
    x2, y2 = pos2
    return abs(x1 - x2) + abs(y1 - y2)

def warehouse_heuristic(current_pos, remaining_items):
    """
    Heuristic for A*: distance to the nearest uncollected item.
    """
    if not remaining_items:
        return 0
    return min(manhattan_distance(current_pos, item) for item in remaining_items)