# graph.py
class WarehouseGrid:
    def __init__(self, size, items):
        self.size = size  # grid size (NxN)
        self.items = items  # list of item coordinates [(x1,y1), (x2,y2), ...]

    def in_bounds(self, pos):
        x, y = pos
        return 0 <= x < self.size and 0 <= y < self.size

    def get_neighbors(self, pos):
        x, y = pos
        directions = [(0,1), (0,-1), (1,0), (-1,0)]
        neighbors = []
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if self.in_bounds((nx, ny)):
                neighbors.append((nx, ny))
        return neighbors