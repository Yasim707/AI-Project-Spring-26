# main.py
from graph import WarehouseGrid
from Astar import a_star_search

def main():
    print("=== Warehouse Item Picker ===")
    size = int(input("Enter grid size (NxN): "))
    start_x = int(input("Enter start X coordinate: "))
    start_y = int(input("Enter start Y coordinate: "))
    start = (start_x, start_y)

    num_items = int(input("Enter number of items to pick: "))
    items = []
    for i in range(num_items):
        x = int(input(f"Enter X coordinate of item {i+1}: "))
        y = int(input(f"Enter Y coordinate of item {i+1}: "))
        items.append((x, y))

    grid = WarehouseGrid(size, items)
    path, cost = a_star_search(grid, start, items)

    if path:
        print("\nOptimal Path:")
        print(" -> ".join(str(p) for p in path))
        print(f"Total Steps: {cost}")
    else:
        print("No path found.")

if __name__ == "__main__":
    main()