# astar.py
import heapq
from graph import WarehouseGrid
from heuristic import warehouse_heuristic

class Node:
    def __init__(self, pos, collected_items, g=0, h=0, parent=None):
        self.pos = pos
        self.collected_items = tuple(sorted(collected_items))
        self.g = g
        self.h = h
        self.f = g + h
        self.parent = parent

    def __lt__(self, other):
        return self.f < other.f

def a_star_search(grid, start, items):
    start_node = Node(start, collected_items=[])
    open_list = []
    heapq.heappush(open_list, start_node)
    closed_set = set()

    while open_list:
        current = heapq.heappop(open_list)

        # Goal test: all items collected
        if set(current.collected_items) == set(items):
            path = []
            node = current
            while node:
                path.append(node.pos)
                node = node.parent
            return path[::-1], current.g  # return path and cost

        state_id = (current.pos, current.collected_items)
        if state_id in closed_set:
            continue
        closed_set.add(state_id)

        # Determine remaining items
        remaining_items = [item for item in items if item not in current.collected_items]

        # Generate neighbors
        for neighbor_pos in grid.get_neighbors(current.pos):
            collected = list(current.collected_items)
            if neighbor_pos in remaining_items:
                collected.append(neighbor_pos)
            g_new = current.g + 1
            h_new = warehouse_heuristic(neighbor_pos, [item for item in items if item not in collected])
            neighbor_node = Node(neighbor_pos, collected, g_new, h_new, parent=current)
            heapq.heappush(open_list, neighbor_node)

    return None, None  # No path found