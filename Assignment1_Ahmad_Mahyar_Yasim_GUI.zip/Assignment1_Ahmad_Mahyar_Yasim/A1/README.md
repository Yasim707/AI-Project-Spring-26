# Warehouse Item Picker – Optimal Path Finder
## Overview
This project implements a Warehouse Item Picker system using the A* search algorithm. It determines the optimal path for a worker or robot to collect multiple items placed at different locations inside a warehouse grid. The objective is to minimize the total number of steps required to collect all items.

The system models the warehouse as a grid where:
- Each cell represents a valid position.
- The worker can move up, down, left, or right.
- Each move has a cost of 1 step.

The system allows users to:
- Run a predefined demo scenario, or  
- Enter custom starting and item locations through the console.

## Dependencies
- Python 3.x  
Uses standard library modules:
- `heapq` (for priority queue in A* search)
- `tkinter` (for graphical user interface and visualization)

No external libraries are required.

## Execution Instructions
1. Open a terminal or command prompt.  
2. Navigate to the project directory.  
3. Run the main program:
bash
python main.py

4. Follow the prompts:
   - Enter the warehouse grid size (e.g., 5 for a 5×5 grid)  
   - Enter the starting coordinates (X, Y)  
   - Enter the number of items to collect  
   - Enter coordinates of each item  
The system will compute and display the optimal path and total number of steps.

## Sample Input/Output
### Input:
Grid size: 5
Start position: (2, 2)
Number of items: 2
Item 1: (0, 0)
Item 2: (4, 4)

### Output:
Start Position: (2, 2)
Items to Pick: [(0, 0), (4, 4)]

Optimal Path:
(2,2) -> (2,1) -> (1,1) -> (0,0) -> (1,0) -> (2,0) -> (3,0) -> (4,0) -> (4,1) -> (4,2) -> (4,3) -> (4,4)

Total Steps: 12
States Explored: 15


## Technical Overview
### Problem Representation
The problem is represented as a state-space search problem where:
- A state consists of:
  - Current position of the worker  
  - Set of collected items  
- The goal state is reached when all items are collected

### Search Algorithm
The A* search algorithm is used to explore the state space efficiently
Evaluation function:
f(n) = g(n) + h(n)
Where:
- `g(n)` = cost (steps) taken so far  
- `h(n)` = heuristic estimate of remaining cost  

### Heuristic Function
The heuristic is based on Manhattan distance:
h(n) = Manhattan distance to the nearest uncollected item

This heuristic is:
- Admissible (never overestimates)
- Consistent
- Guarantees optimal path when used with A*

### Program Structure
- `graph.py`  
  Defines the warehouse grid and valid neighbor movements.
- `heuristic.py`  
  Implements Manhattan distance heuristic.
- `astar.py`  
  Implements the A* search algorithm and state tracking.
- `main.py`  
  Provides a Tkinter-based graphical user interface that allows users to enter grid parameters, run the A* search algorithm, and visualize the warehouse graph along with the optimal path.
## Features
- Finds shortest path to collect all items  
- Supports custom grid sizes  
- Handles multiple item locations  
- Displays:
  - Full movement path  
  - Total steps  
  - Number of explored states  

## Graphical Visualization

The system also includes a Tkinter-based graphical interface to improve usability and demonstrate the search process visually.

Features of the GUI:

- User inputs grid size, start position, and item coordinates through input fields
- The warehouse grid is displayed as a node graph
- Nodes represent grid coordinates
- Edges represent valid movements between positions
- Start node is highlighted in green
- Item locations are highlighted in blue
- The optimal path discovered by the A* algorithm is highlighted in red
- Scrollbars allow visualization of larger grids without layout limitations

This visualization helps users clearly understand how the algorithm navigates the warehouse and determines the optimal route.

## Limitations
- No obstacles are considered  
- Only four-directional movement (up, down, left, right)  
- Designed for small grids (5×5 or 6×6)  
- Console-based interface only

## Future Improvements
- Add obstacles and blocked cells  
- Implement graphical interface (Tkinter or PyQt)  
- Support multiple workers  
- Add diagonal movement  
- Compare A* with BFS and DFS  

## Author & Submission
Course: AI2002 – Artificial Intelligence  
Assignment: Search Algorithm Implementation  
Instructor: Muhammad Bilal
Group: 
Muhammad Mahyar Zeb   23i2031
Muhammad Yasim Malik  23i3001
Muhammad Ahmed        23i2516
This project demonstrates:
- Problem modeling  
- Heuristic design  
- A* search implementation  
- Console-based interaction  
