import tkinter as tk
from tkinter import messagebox

from graph import WarehouseGrid
from Astar import a_star_search

# ==============================
# RUN SEARCH
# ==============================

def run_search():

    try:
        size = int(entry_size.get())
        start_x = int(entry_start_x.get())
        start_y = int(entry_start_y.get())

        start = (start_x, start_y)

        items = []
        items_text = text_items.get("1.0", tk.END).strip().split("\n")

        for line in items_text:
            if line.strip() == "":
                continue
            x, y = map(int, line.split(","))
            items.append((x, y))

        grid = WarehouseGrid(size, items)

        path, cost = a_star_search(grid, start, items)

        output_text.delete("1.0", tk.END)

        if path:
            output_text.insert(tk.END, "Optimal Path:\n")
            output_text.insert(tk.END, " -> ".join(str(p) for p in path))
            output_text.insert(tk.END, f"\n\nTotal Steps: {cost}")
        else:
            output_text.insert(tk.END, "No path found.")

        draw_graph(size, start, items, path)

    except Exception as e:
        messagebox.showerror("Error", str(e))


# ==============================
# DRAW GRAPH
# ==============================

def draw_graph(size, start, items, path=None):

    canvas.delete("all")

    cell = 80
    padding = 50

    width = size * cell + padding
    height = size * cell + padding

    canvas.config(scrollregion=(0, 0, width, height))

    node_pos = {}

    # Generate node positions
    for x in range(size):
        for y in range(size):

            px = padding + y * cell
            py = padding + x * cell

            node_pos[(x, y)] = (px, py)

    # Draw edges
    for x in range(size):
        for y in range(size):

            cx, cy = node_pos[(x, y)]

            neighbors = [(x + 1, y), (x, y + 1)]

            for nx, ny in neighbors:

                if 0 <= nx < size and 0 <= ny < size:

                    nxp, nyp = node_pos[(nx, ny)]

                    canvas.create_line(
                        cx, cy,
                        nxp, nyp,
                        fill="gray"
                    )

    # Highlight optimal path
    if path:

        for i in range(len(path) - 1):

            x1, y1 = node_pos[path[i]]
            x2, y2 = node_pos[path[i + 1]]

            canvas.create_line(
                x1, y1,
                x2, y2,
                fill="red",
                width=3
            )

    # Draw nodes
    for pos, (x, y) in node_pos.items():

        color = "white"

        if pos == start:
            color = "green"

        elif pos in items:
            color = "blue"

        if path and pos in path:
            color = "red"

        r = 10

        canvas.create_oval(
            x - r, y - r,
            x + r, y + r,
            fill=color,
            outline="black"
        )

        canvas.create_text(
            x,
            y - 15,
            text=str(pos),
            font=("Arial", 8)
        )


# ==============================
# GUI
# ==============================

root = tk.Tk()
root.title("Warehouse Item Picker (A* Visualization)")
root.geometry("700x750")

title = tk.Label(root, text="Warehouse Item Picker", font=("Arial", 16))
title.pack(pady=10)

frame_inputs = tk.Frame(root)
frame_inputs.pack()

tk.Label(frame_inputs, text="Grid Size (NxN):").grid(row=0, column=0)
entry_size = tk.Entry(frame_inputs)
entry_size.grid(row=0, column=1)

tk.Label(frame_inputs, text="Start X:").grid(row=1, column=0)
entry_start_x = tk.Entry(frame_inputs)
entry_start_x.grid(row=1, column=1)

tk.Label(frame_inputs, text="Start Y:").grid(row=2, column=0)
entry_start_y = tk.Entry(frame_inputs)
entry_start_y.grid(row=2, column=1)

items_label = tk.Label(root, text="Enter Item Coordinates (x,y per line)")
items_label.pack(pady=10)

text_items = tk.Text(root, height=5)
text_items.pack()

run_button = tk.Button(root, text="Run A* Search", command=run_search)
run_button.pack(pady=10)

output_label = tk.Label(root, text="Output")
output_label.pack()

output_text = tk.Text(root, height=6)
output_text.pack()

# ==============================
# SCROLLABLE CANVAS
# ==============================

frame_canvas = tk.Frame(root)
frame_canvas.pack(fill=tk.BOTH, expand=True)

canvas = tk.Canvas(frame_canvas, bg="white")

scroll_y = tk.Scrollbar(frame_canvas, orient="vertical", command=canvas.yview)
scroll_x = tk.Scrollbar(frame_canvas, orient="horizontal", command=canvas.xview)

canvas.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)

scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
scroll_x.pack(side=tk.BOTTOM, fill=tk.X)

canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

root.mainloop()